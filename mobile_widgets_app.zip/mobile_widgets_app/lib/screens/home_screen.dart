import 'package:flutter/material.dart';

import '../widgets/animated_counter.dart';
import 'products_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Animated Counter')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const AnimatedCounter(maxValue: 10),
            const SizedBox(height: 40),
            FilledButton.icon(
              icon: const Icon(Icons.shopping_bag_outlined),
              label: const Text('Товари'),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ProductsScreen()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
