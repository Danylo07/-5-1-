import 'package:flutter/material.dart';

import '../models/product.dart';
import '../utils/constants.dart';
import '../widgets/product_card.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  late List<Product> _products;
  int _cartCount = 0;

  @override
  void initState() {
    super.initState();
    _products = List.of(kSampleProducts);
  }

  void _toggleFavorite(int index) {
    setState(() {
      final p = _products[index];
      _products[index] = p.copyWith(isFavorite: !p.isFavorite);
    });
  }

  void _addToCart(Product product) {
    setState(() => _cartCount++);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text('«${product.name}» додано в кошик'),
          duration: const Duration(seconds: 1),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Товари'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Badge(
                label: Text('$_cartCount'),
                isLabelVisible: _cartCount > 0,
                child: const Icon(Icons.shopping_cart_outlined),
              ),
            ),
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: _products.length,
        itemBuilder: (context, i) => ProductCard(
          product: _products[i],
          onFavoriteToggle: () => _toggleFavorite(i),
          onAddToCart: () => _addToCart(_products[i]),
        ),
      ),
    );
  }
}
