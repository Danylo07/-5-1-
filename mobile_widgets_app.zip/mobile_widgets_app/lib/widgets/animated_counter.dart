import 'package:flutter/material.dart';

import 'bounce_tap.dart';

/// Анімований лічильник:
/// - scale-анімація цифри при зміні значення
/// - перехід кольору при досягненні maxValue
/// - bounce на кнопках
/// - плавний progress indicator
///
/// Приклад:
/// ```dart
/// AnimatedCounter(initialValue: 5, maxValue: 10, primaryColor: Colors.indigo)
/// ```
class AnimatedCounter extends StatefulWidget {
  final int initialValue;
  final int maxValue;
  final Duration animationDuration;
  final Color? primaryColor;

  const AnimatedCounter({
    Key? key,
    this.initialValue = 0,
    this.maxValue = 100,
    this.animationDuration = const Duration(milliseconds: 300),
    this.primaryColor,
  }) : super(key: key);

  @override
  State<AnimatedCounter> createState() => _AnimatedCounterState();
}

class _AnimatedCounterState extends State<AnimatedCounter>
    with TickerProviderStateMixin {
  late AnimationController _controller; // scale цифри
  late AnimationController _colorController; // перехід кольору
  late Animation<double> _animation;
  late int _value;

  @override
  void initState() {
    super.initState();
    _value = widget.initialValue.clamp(0, widget.maxValue);

    _controller = AnimationController(
      vsync: this,
      duration: widget.animationDuration,
    );
    _animation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween(begin: 1.0, end: 1.4)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 40,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 1.4, end: 1.0)
            .chain(CurveTween(curve: Curves.easeIn)),
        weight: 60,
      ),
    ]).animate(_controller);

    _colorController = AnimationController(
      vsync: this,
      duration: widget.animationDuration,
      value: _value >= widget.maxValue ? 1.0 : 0.0,
    );
  }

  @override
  void didUpdateWidget(covariant AnimatedCounter oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.animationDuration != widget.animationDuration) {
      _controller.duration = widget.animationDuration;
      _colorController.duration = widget.animationDuration;
    }
    if (oldWidget.maxValue != widget.maxValue) {
      _value = _value.clamp(0, widget.maxValue);
      _syncColor();
    }
  }

  void _syncColor() {
    if (_value >= widget.maxValue) {
      _colorController.forward();
    } else {
      _colorController.reverse();
    }
  }

  void _change(int delta) {
    final next = (_value + delta).clamp(0, widget.maxValue);
    if (next == _value) return;
    setState(() => _value = next);
    _controller.forward(from: 0);
    _syncColor();
  }

  @override
  void dispose() {
    _controller.dispose();
    _colorController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final base = widget.primaryColor ?? Theme.of(context).colorScheme.primary;

    return AnimatedBuilder(
      animation: _colorController,
      builder: (context, _) {
        final color = Color.lerp(base, Colors.green, _colorController.value)!;

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ScaleTransition(
              scale: _animation,
              child: Text(
                '$_value',
                style: TextStyle(
                  fontSize: 56,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: TweenAnimationBuilder<double>(
                tween: Tween<double>(
                  begin: 0,
                  end: widget.maxValue == 0 ? 0 : _value / widget.maxValue,
                ),
                duration: widget.animationDuration,
                curve: Curves.easeOut,
                builder: (context, progress, _) => ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 10,
                    color: color,
                    backgroundColor: color.withOpacity(0.2),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _RoundButton(
                  icon: Icons.remove,
                  color: color,
                  onTap: _value > 0 ? () => _change(-1) : null,
                ),
                const SizedBox(width: 24),
                _RoundButton(
                  icon: Icons.add,
                  color: color,
                  onTap: _value < widget.maxValue ? () => _change(1) : null,
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _RoundButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;

  const _RoundButton({
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return BounceTap(
      onTap: onTap,
      child: Container(
        width: 56,
        height: 56,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: enabled ? color : Colors.grey.shade300,
        ),
        child: Icon(icon, color: Colors.white),
      ),
    );
  }
}
