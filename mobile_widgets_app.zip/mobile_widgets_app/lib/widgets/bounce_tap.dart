import 'package:flutter/material.dart';

/// Обгортка, що додає bounce-ефект при натисканні на будь-який віджет.
class BounceTap extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;

  const BounceTap({super.key, required this.child, this.onTap});

  @override
  State<BounceTap> createState() => _BounceTapState();
}

class _BounceTapState extends State<BounceTap>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    // Широкі межі, щоб elasticOut міг "перестрибнути" 1.0
    _controller = AnimationController(
      vsync: this,
      lowerBound: 0.5,
      upperBound: 1.2,
      value: 1.0,
    );
  }

  void _onDown(TapDownDetails _) {
    _controller.animateTo(
      0.85,
      duration: const Duration(milliseconds: 80),
    );
  }

  void _release() {
    _controller.animateTo(
      1.0,
      duration: const Duration(milliseconds: 450),
      curve: Curves.elasticOut,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: widget.onTap == null ? null : _onDown,
      onTapUp: widget.onTap == null
          ? null
          : (_) {
              _release();
              widget.onTap!.call();
            },
      onTapCancel: widget.onTap == null ? null : _release,
      child: ScaleTransition(scale: _controller, child: widget.child),
    );
  }
}
