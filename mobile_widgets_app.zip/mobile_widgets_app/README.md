# mobile_widgets_app

Flutter-додаток з custom віджетами (Практична робота 5, «Програмування для мобільних платформ»).

**Автор:** _[ПІБ, група ІК-41]_

## Реалізовані віджети

| Віджет | Опис |
|---|---|
| `AnimatedCounter` | Лічильник: scale цифри, зміна кольору на максимумі, bounce-кнопки, плавний progress bar |
| `ProductCard` | Картка товару: swipe для favorite, zoom зображення по тапу, shimmer при завантаженні, tap-анімації |
| `BounceTap` | Обгортка з bounce-ефектом для будь-якого віджета |

## Структура

```
lib/
├── main.dart
├── screens/   (home_screen, products_screen)
├── widgets/   (animated_counter, product_card, bounce_tap)
├── models/    (product)
└── utils/     (constants, themes)
test/widgets/  (animated_counter_test, product_card_test)
```

## Запуск

Потрібно: Flutter 3.16.0+, Dart 3.0+.

```bash
git clone <URL репозиторію>
cd mobile_widgets_app
flutter create .        # генерує android/ios/web (один раз)
flutter pub get
flutter run             # або: flutter run -d chrome
```

## Тести та аналіз

```bash
flutter analyze
flutter test --coverage
```

## Збірка

```bash
flutter build web --release
flutter build apk --release
```

## Скріншоти

_Додайте скріншоти в `docs/screenshots/` і вставте сюди._
